<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		$serverTime = date("Y-m-d H:i:s");
	?>
	<p>Timezone is : <?php echo date_default_timezone_get(); ?></p>
	<p>Server time is : <?php echo date("Y-m-d H:i:s"); ?></p>
	

	<?php
		date_default_timezone_set("Asia/jakarta");
		$currentTime = date("Y-m-d H:i:s");

		$diff = strtotime($currentTime) - strtotime($serverTime);
	?>

	<p>Jakarta time is : <?php echo date("Y-m-d H:i:s");  ?></p>
	<!-- <p><?php echo date("H:i:s", $diff - (7*3600)); ?></p> -->
	<?php 
		$datetime1 = new DateTime($serverTime);
		$datetime2 = new DateTime($currentTime);
	?>
	<p>Time difference is : <?php echo $datetime1->diff($datetime2)->format("%R%H:%I:%S"); ?></p>
</body>
</html>