<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

defined('BASEPATH') OR exit('No direct script access allowed');

class Model_name_model extends CI_Model {

	public function __construct() 
	{
		parent::__construct();
	}

	public function Foo()
	{
		//some code...
	}

}